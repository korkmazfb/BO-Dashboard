#define WIFI_SSID "Medialab"
#define WIFI_PASSWORD "Mediacollege2"
#define SERVER_HOST "data.softwaredeveloper.amsterdam"
#define SERVER_PORT 443
#define DEVICE_KEY "038ab0cc" // gebruik jouw eigen key
#define DEVICE_SECRET "pudeMacU" // gebruik jouw eigen secret
