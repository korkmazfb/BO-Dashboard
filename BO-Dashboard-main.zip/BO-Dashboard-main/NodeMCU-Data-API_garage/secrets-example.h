#define WIFI_SSID "ChangeMe"
#define WIFI_PASSWORD "ChangeMe"
#define SERVER_HOST "data.softwaredeveloper.amsterdam"
#define SERVER_PORT 443
#define DEVICE_KEY "ChangeMe"
#define DEVICE_SECRET "ChangeMe"
