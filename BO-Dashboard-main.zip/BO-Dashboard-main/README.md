# [link naar de liveserver van onze Dashboard](https://32840.hosts1.ma-cloud.nl/BO-dashboard/)

## Taakverdeling

### Groepje
### 1.Mert Korkmaz
### 2.Bilal el Koudadi
### 3.Halil Dogan
### 4.Liam Bojoha (VMBO Leerlingen)


### Halil Dogan
#### 6.De actuele binnentemperatuurin een ruimte: slaapkamer, klaslokaal, kantoor(meten met een sensor en weergeven op het dashboard). Meerdere ruimten mogelijk.
#### 5.De tijd dat de zon ondergaat. De tijd dat de zon opkomt.
#### 4.Een grafische weergave van het water verbruik de afgelopen weken.


### Mert Korkmaz
#### 4.Het weerbericht (via een API) van vandaag.
#### 2.Een grafische weergave van de het stroomverbruik de afgelopen weken huishouden1, huishouden 2, huishouden 3.huishoudens.
#### 4.een lampje aan of uit gaat als er beweging is(het licht in de WC, devoorraadkast, de kelder, een klaslokaal gaat aan als er beweging is na bepaalde tijd gaat het automatisch uit)
#### 1.Een lampje aan of uit afhankelijk van delichtintensiteit(donker buiten> lampaan in huis, licht buiten> lamp uit in huis).

### Bilal el Koudadi
#### 6.De actuele binnentemperatuur in een ruimte: slaapkamer, klaslokaal, kantoor(meten met een sensor en weergeven op het dashboard). Meerdere ruimten mogelijk.
#### 2.Een grafische weergave van de het stroomverbruik de afgelopen weken huishouden1, huishouden 2, huishouden 3.huishoudens.
#### 1.Een lampje aan of uit afhankelijk van delichtintensiteit(donker buiten> lampaan in huis, licht buiten> lamp uit in huis).



#### Dit zijn de verdelingen."# BO-Dashboard" 


